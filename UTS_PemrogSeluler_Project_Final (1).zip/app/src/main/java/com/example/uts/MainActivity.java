
package com.example.uts;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    EditText etNama, etMatkul;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNama = findViewById(R.id.etNama);
        etMatkul = findViewById(R.id.etMatkul);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> {

            String nama = etNama.getText().toString();
            String matkul = etMatkul.getText().toString();

            Intent intent = new Intent(MainActivity.this, PanelActivity.class);
            intent.putExtra("nama", nama);
            intent.putExtra("matkul", matkul);

            startActivity(intent);

        });
    }
}
