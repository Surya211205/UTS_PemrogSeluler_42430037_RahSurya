
package com.example.uts;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;

public class PanelActivity extends AppCompatActivity {

    TextView tvInfo, tvOutput;
    EditText etJumlah;
    Button btnGenerate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panel);

        tvInfo = findViewById(R.id.tvInfo);
        tvOutput = findViewById(R.id.tvOutput);
        etJumlah = findViewById(R.id.etJumlah);
        btnGenerate = findViewById(R.id.btnGenerate);

        String nama = getIntent().getStringExtra("nama");
        String matkul = getIntent().getStringExtra("matkul");

        tvInfo.setText("Dosen: " + nama + "\nMata Kuliah: " + matkul);

        btnGenerate.setOnClickListener(v -> {

            int jumlah = Integer.parseInt(etJumlah.getText().toString());

            String hasil = "";

            for(int i=1;i<=jumlah;i++){

                int nilai = 50 + (int)(Math.random()*50);

                String status;

                if(nilai >= 75){
                    status = "LULUS";
                }else{
                    status = "TIDAK LULUS";
                }

                hasil += "Mahasiswa " + i +
                        " | Nilai: " + nilai +
                        " | Status: " + status + "\n";
            }

            tvOutput.setText(hasil);

        });
    }
}
